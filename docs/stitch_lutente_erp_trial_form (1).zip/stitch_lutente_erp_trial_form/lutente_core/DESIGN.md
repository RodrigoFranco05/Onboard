---
name: Lutente Core
colors:
  surface: '#fff8f3'
  surface-dim: '#e4d8c9'
  surface-bright: '#fff8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff2e2'
  surface-container: '#f9ecdc'
  surface-container-high: '#f3e6d7'
  surface-container-highest: '#ede1d1'
  on-surface: '#201b11'
  on-surface-variant: '#504533'
  inverse-surface: '#362f25'
  inverse-on-surface: '#fcefdf'
  outline: '#837560'
  outline-variant: '#d5c4ac'
  surface-tint: '#7c5800'
  primary: '#7c5800'
  on-primary: '#ffffff'
  primary-container: '#f4b10e'
  on-primary-container: '#654700'
  inverse-primary: '#ffbb1e'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2e1'
  on-secondary-container: '#656464'
  tertiary: '#5e5e5f'
  on-tertiary: '#ffffff'
  tertiary-container: '#bdbdbd'
  on-tertiary-container: '#4b4c4d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdea7'
  primary-fixed-dim: '#ffbb1e'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5e4200'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c9c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#e3e2e2'
  tertiary-fixed-dim: '#c7c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#464747'
  background: '#fff8f3'
  on-background: '#201b11'
  surface-variant: '#ede1d1'
typography:
  display-lg:
    fontFamily: Raleway
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Raleway
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Raleway
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Raleway
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Raleway
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Raleway
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Raleway
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Raleway
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin: 32px
---

## Brand & Style

The visual identity of the design system is anchored in **Corporate Modernism**. It prioritizes clarity, high-trust, and precision to support the complex workflows inherent in an ERP environment. The aesthetic is professional and airy, utilizing significant white space to reduce cognitive load while employing a high-contrast palette to guide user attention.

The personality is authoritative yet accessible. By combining a utilitarian light-neutral background with a vibrant, energetic primary yellow, the system balances the reliability of enterprise software with the freshness of a modern SaaS platform. The focus is on functionality and data density without sacrificing visual elegance.

## Colors

This design system utilizes a high-contrast, intentional palette designed for readability and action-oriented navigation:

- **Primary Yellow (#F4B10E):** Reserved exclusively for primary Call-to-Action (CTA) buttons, progress indicators, and critical highlights. It provides an immediate visual hook against the neutral backdrop.
- **Dark Neutral (#0E0E0E):** Used for primary typography, iconography, and high-emphasis UI elements like sidebars or headers to ground the interface.
- **Light Background (#F8F7F7):** The global canvas color. It creates a soft, non-fatiguing environment for long-term daily use.
- **Surface White (#FFFFFF):** Used for cards, input fields, and containers to create subtle separation from the light neutral background.

## Typography

Raleway is the sole typeface, chosen for its elegant yet geometric structure. In an ERP context, the slight "display" qualities of Raleway (like the 'W' and 'L') add a distinctive brand character without compromising legibility.

- **Weight Strategy:** Use Bold (700) and SemiBold (600) for structural hierarchy. Regular (400) is used for all long-form data and body copy to ensure clarity.
- **Scaling:** On mobile devices, `display-lg` should scale down to 32px to ensure it fits within the viewport, while body text remains consistent at 16px to maintain readability.
- **Labels:** Form labels and small captions utilize increased letter spacing and medium/semibold weights to ensure they are distinct from the data values they describe.

## Layout & Spacing

The design system employs a **12-column fluid grid** for desktop, transitioning to a **4-column fluid grid** for mobile devices. 

- **Desktop (1440px+):** 32px side margins, 24px gutters.
- **Tablet (768px - 1439px):** 24px side margins, 16px gutters.
- **Mobile (<767px):** 16px side margins, 12px gutters.

Spacing follows an 8px rhythmic scale. Use `md` (24px) for standard padding within cards and containers to maintain the "airy" feel requested. Data-heavy tables should utilize a more compact 12px vertical padding to maximize information density.

## Elevation & Depth

Hierarchy is achieved through **Tonal Layering** and **Low-Contrast Outlines** rather than heavy shadows. This keeps the interface feeling flat, modern, and high-performance.

- **Level 0 (Background):** #F8F7F7.
- **Level 1 (Cards/Content):** #FFFFFF with a 1px solid border of #E5E4E4.
- **Level 2 (Modals/Popovers):** #FFFFFF with a soft, diffused shadow (0px 8px 24px rgba(14, 14, 14, 0.08)) to indicate temporary interaction.
- **Interactive States:** On hover, cards should transition to a slightly darker border (#D1D1D1) rather than lifting, maintaining the structural integrity of the grid.

## Shapes

The shape language is "Soft," utilizing a consistent 0.25rem (4px) corner radius. This choice avoids the clinical feel of sharp corners while remaining professional enough for an enterprise tool.

- **Buttons & Inputs:** 4px radius.
- **Cards & Containers:** 8px (rounded-lg) for a more defined structural presence.
- **Selection Indicators:** Use pill-shaped (full radius) only for status chips (e.g., "Active", "Pending") to differentiate them from functional buttons.

## Components

### Buttons
- **Primary:** Background #F4B10E, Text #0E0E0E, Weight 600.
- **Secondary:** Transparent background, 1px Border #0E0E0E, Text #0E0E0E.
- **Ghost:** Transparent background, Text #0E0E0E, for low-priority actions.

### Input Fields
- **Default State:** White background, 1px border (#E5E4E4), 12px horizontal padding.
- **Focus State:** 1px border #F4B10E with a subtle 2px outer glow of the same color at 20% opacity.
- **Labels:** Use `label-md` placed 8px above the input field.

### Cards
- Use for dashboard widgets and grouping related ERP data. 
- Style: White background, 1px border #E5E4E4, 24px internal padding.

### Data Tables
- Header row: Light grey (#F0F0F0), Bold 14px Raleway text.
- Row divider: 1px solid #F0F0F0.
- Hover state: Row background changes to #F8F7F7.

### Status Chips
- Small, pill-shaped indicators using low-saturation versions of semantic colors (Success-Green, Error-Red, Warning-Yellow) to ensure they don't compete with primary CTAs.