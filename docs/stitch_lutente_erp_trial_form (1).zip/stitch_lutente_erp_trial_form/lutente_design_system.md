# Lutente Core: Sistema de Diseño Integral

Este documento define la arquitectura visual y las reglas de implementación para el flujo de onboarding de Lutente ERP, garantizando consistencia absoluta en componentes, espaciado y comportamiento.

## 1. Fundamentos Visuales

### Paleta de Colores
- **Surface (Body background):** `#ffffff` (Blanco puro).
- **Surface Variant (Main Container):** `#f8f9fa` (Gris ultra claro para el contenedor principal).
- **Primary (CTAs):** `#f4b10e` (Amarillo Lutente).
- **Primary Hover:** `#d99d0c`.
- **On Primary (CTA Text):** `#1a1a1a` (Casi negro).
- **Secondary (Accents):** `#8d5b0a` (Marrón Dorado para indicadores de pasos).
- **Outline (Borders):** `#e4d8c9` (Beige neutro).
- **Success:** `#10b981` (Esmeralda para estados de éxito).

### Tipografía
- **Fuente:** **Raleway** (Sans-serif moderna).
- **Headlines (H1):** 32px | Bold (700) | `#1a1a1a` | Margin-bottom: 8px.
- **Subtitles:** 16px | Regular (400) | `#9a8d7c` | Margin-bottom: 32px.
- **Section Headers:** 18px | Bold (700) | `#1a1a1a` | Icono a la izquierda con gap de 8px.
- **Labels:** 14px | Bold (700) | `#1a1a1a` | Margin-bottom: 8px.
- **Body / Content:** 14px | Medium (500) | `#1a1a1a`.
- **Placeholder:** 14px | Regular (400) | `#9a8d7c`.

### Sombras y Elevación
- **Shadow:** `0px 4px 20px rgba(0, 0, 0, 0.05)`.
- **Uso:** Exclusivamente en el contenedor principal de la tarjeta central para separarla del fondo del body.

## 2. Contenedores Estructurales

### Body
- **Background:** `#ffffff`.
- **Layout:** Flexbox centrado vertical y horizontalmente (min-h-screen).

### Contenedor Principal (Main Card)
- **Ancho:** `800px` a `900px` (Desktop).
- **Background:** `#ffffff`.
- **Border:** `1px solid #e4d8c9`.
- **Border Radius:** `12px`.
- **Padding:** `48px` internos.
- **Header:** Logo centrado o a la izquierda según el paso. Línea divisoria inferior de `4px` color `#f4b10e` en pasos de formulario.

## 3. Componentes de UI

### Botones (CTAs)
- **Primary Button:**
  - **Fondo:** `#f4b10e`.
  - **Texto:** `#1a1a1a`, Bold, 14px.
  - **Padding:** `12px 24px`.
  - **Radius:** `8px`.
  - **Hover:** Cambio de fondo a `#d99d0c`, elevación ligera.
  - **Icono:** `arrow_forward` (Material Symbol) a la derecha, gap 8px.
- **Secondary / Back Button:**
  - **Estilo:** Ghost/Text.
  - **Texto:** `#1a1a1a`, Medium, 14px.
  - **Icono:** `arrow_back` a la izquierda.

### Entradas de Texto (Inputs)
- **Border:** `1px solid #e4d8c9`.
- **Background:** `#f8f9fa`.
- **Radius:** `8px`.
- **Padding:** `12px 16px`.
- **Focus State:** Borde cambia a `#f4b10e`, ring sutil de `2px` con opacidad.

### Stepper (Barra de Pasos)
- **Horizontal (Top):** Barra de progreso de `4px` de alto. Color `#f4b10e` para el progreso actual, `#e4d8c9` para el restante.
- **Vertical (Sidebar - Opcional):**
  - **Círculo Activo:** Borde `#8d5b0a`, punto central `#8d5b0a`.
  - **Círculo Completado:** Fondo `#8d5b0a` con check blanco.

### Módulos (Checkboxes/Cards)
- **Card State (Normal):** Borde `#e4d8c9`, background blanco.
- **Card State (Selected):** Borde `2px solid #f4b10e`, background `#fffcf5`.
- **Checkbox:** Círculo de `20px`. Seleccionado: Fondo `#f4b10e` con check.

## 4. Iconografía
- **Estilo:** Material Symbols Outlined.
- **Tamaño:** 20px para UI general, 32px para encabezados de sección.
- **Color:** `#f4b10e` para acentos decorativos, `#1a1a1a` para iconos funcionales.